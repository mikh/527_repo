git add *
git commit -m "HW2 Part 1 Q1"
unset SSH_ASKPASS
git push gg master