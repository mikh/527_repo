gcc -O1 -o test_combine2d test_combine2d.c -lrt
./test_combine2d

